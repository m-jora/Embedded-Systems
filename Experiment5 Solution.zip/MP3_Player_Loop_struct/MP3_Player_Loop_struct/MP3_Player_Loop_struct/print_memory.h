#ifndef _print_bytes_H
#define _print_bytes_H





// ------ Public function prototypes -------------------------------

void print_memory(volatile UART_t * UART_addr, uint16_t number_of_bytes, uint8_t * array_in);


#endif