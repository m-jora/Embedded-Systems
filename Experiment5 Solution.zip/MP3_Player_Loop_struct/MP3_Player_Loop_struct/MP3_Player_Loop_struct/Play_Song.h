#ifndef _Play_Song_H
#define _Play_Song_H

#include "board_struct.h"

//------- Public Constant definitions --------------------------------



// ------ Public function prototypes -------------------------------
void Play_Song(uint32_t Start_Cluster);

#endif